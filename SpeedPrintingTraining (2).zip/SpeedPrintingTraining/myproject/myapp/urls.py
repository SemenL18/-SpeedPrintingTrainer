#myapp\urls.py
from django.urls import path
from myapp import views

urlpatterns = [
    path('', views.select_mode, name='select_mode'),
    path('typing_test/', views.typing_test, name='typing_test'),
]
