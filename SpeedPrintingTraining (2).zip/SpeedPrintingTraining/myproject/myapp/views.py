import random
import time
from django.shortcuts import render, redirect

syllables = [
    "ба ни лу пе са ки ро ме ту ши го мо да ре ку па те",
    "жа фу си но бе те ла до ми ве ло га чу ра по зы шу",
    "шэ ру ко би ти су мо да лы фи во лы жи пе ра со ху",
    "че лю ви но га шу ле ку ди жу сы пе ру зы мо бо бу",
]

simple_words = [
    "кот лес мир свет друг дом рад день снег лес меч полёт",
    "интеграл стул стол сад лес берег ключ мост волна парк",
    "традиция шар луг путь бой звук мост шар лес река дом",
    "скорость звон книга лист мечта ручей звонок поле шар",
    "молоко смех солнечный сад зонт берег улыбка тропа ручка",
    "погода мост облако луна ключ лесок цветок шкаф студент",
]

texts = [
    "Сложные символы: @Python#2023!. Скорость печати важна в современном мире.",
    "КОД - это СИЛА. Python -- язык с лаконичным синтаксисом.",
    "Работа с текстом: быстро, ЧЁТКО, грамотно. Умение быстро печатать экономит время.",
    "Обработка строк: trim(x), split(y), join(z). Пиши код чисто и подробно документируй.",
    "Умей пользоваться: ( ), { }, [ ], ; : ? !. Работа с текстом помогает улучшить внимание.",
]

def get_test_text(mode):
    if mode == '1':
        return random.choice(syllables)
    elif mode == '2':
        return random.choice(simple_words)
    else:
        return random.choice(texts)

def get_mode_name(mode):
    if mode == "1":
        return "Тренировка 'слоги'"
    elif mode == "2":
        return "Тренировка 'слова'"
    else:
        return "Тренировка 'текст'"

def count_position_errors(target, user):
    errors = 0
    min_len = min(len(target), len(user))
    for i in range(min_len):
        if target[i] != user[i]:
            errors += 1
    # Если хочешь учитывать "хвост" тоже:
    errors += abs(len(target) - len(user))
    return errors

def select_mode(request):
    # механика выбора режима
    if request.method == "POST":
        mode = request.POST.get("mode")
        return redirect(f"/typing_test/?mode={mode}")
    return render(request, "select_mode.html")

def typing_test(request):
    mode = request.GET.get("mode", "1")
    if request.method == "POST":
        test_text = request.POST.get("test_text", "")
        user_input = request.POST.get("user_input", "")
        try:
            start_time = float(request.POST.get("start_time", "0"))
        except Exception:
            start_time = 0
        end_time = time.time()
        elapsed = max(end_time - start_time, 0.01)

        # В приоритете — брать ошибки из формы, если передаются сразу в JS (быстрее)
        errors = None
        if 'errors' in request.POST:
            try:
                errors = int(request.POST.get("errors", 0))
            except Exception:
                errors = count_position_errors(test_text.strip(), user_input.strip())
        else:
            errors = count_position_errors(test_text.strip(), user_input.strip())

        word_count = max(len(user_input.strip()) / 5, 0.01)
        wpm = word_count / (elapsed / 60)

        return render(request, "result.html", {
            "elapsed": round(elapsed, 2),
            "errors": errors,
            "wpm": round(wpm, 1),
            "test_text": test_text,
            "user_input": user_input,
            "mode": get_mode_name(mode)
        })
    else:
        test_text = get_test_text(mode)
        return render(request, "typing_test.html", {
            "test_text": test_text,
            "start_time": time.time(),
            "mode": mode,
            "mode_name": get_mode_name(mode)
        })